CREATE MATERIALIZED VIEW search_post AS SELECT posts.id AS post_id,
    (((setweight(to_tsvector('english_nostop'::regconfig, unaccent(COALESCE(posts.title, ''::text))), 'A'::"char") || setweight(to_tsvector('english_nostop'::regconfig, unaccent(COALESCE(posts.description, ''::text))), 'B'::"char")) || setweight(to_tsvector('english_nostop'::regconfig, unaccent(users.full_name)), 'D'::"char")) || setweight(to_tsvector('english_nostop'::regconfig, unaccent(string_agg(COALESCE(tags.title, ''::text), ','::text))), 'C'::"char")) AS full_post
   FROM ((blog.posts posts
     JOIN auth.users users ON ((posts.author_id = users.id)))
     LEFT JOIN blog.tags tags ON ((tags.id = ANY (posts.tag_ids))))
  WHERE ((posts.status = 1) AND (posts.post_type = 0))
  GROUP BY posts.id, users.full_name;

create unique index idx_unique
  on search_post (post_id);

create index idx_search_post
  on search_post (full_post);

